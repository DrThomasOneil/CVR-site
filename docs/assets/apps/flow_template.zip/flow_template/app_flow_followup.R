
library(Spectre)
library(ggplot2)
library(DT)
library(data.table)
library(cowplot)
library(dplyr)

data <- readRDS("output/rds/20240923_1732_TO_wGut_clustered_data.rds")
info <- readRDS("output/rds/20240923_1732_TO_wGut_integration_info.rds")

head(data)
info
colnames(data)[info$markers]

# Follow up Analysis ------------------------------------------------------

plot_grid(
  ggplot(data, aes(UMAP_X, UMAP_Y, color=sample))+geom_density_2d(n=100, contour_var = 'ndensity', show.legend = F)+ggtitle("No integration")+
    scale_color_manual(values = colorRampPalette(c("blue","red"))(length(unique(data$sample))))
  ,
  ggplot(data, aes(UMAP_X_rPCA, UMAP_Y_rPCA, color=sample))+geom_density_2d(n=100, contour_var = 'ndensity', show.legend = T)+ggtitle("Integration")+
    scale_color_manual(values = colorRampPalette(c("blue", "red"))(length(unique(data$sample))))
)


# FlowSOM figure ----------------------------------------------------------

ggplot(data, aes(UMAP_X_rPCA, UMAP_Y_rPCA, color=as.factor(FlowSOM_metacluster)))+
  geom_point(show.legend=F)+theme_bw()

# In case you want to play around with SOMs numbers -----------------------

dat <- data[,-c(26,27)] # remove last 2 columns 
cluster <- run.flowsom(dat, grep("aligned", colnames(dat),value=T), 
                       meta.k =9) # change meta.k to number of clusters. 
ggplot(cluster, aes(UMAP_X_rPCA, UMAP_Y_rPCA, color=as.factor(FlowSOM_metacluster)))+
  geom_point(show.legend=T)+theme(legend.title = element_text(size=0))

make.colour.plot(cluster, "UMAP_X_rPCA", "UMAP_Y_rPCA", "FlowSOM_metacluster", col.type = 'factor', add.label = TRUE, save.to.disk = F, blank.axis = T)+ggtitle("")

data <- cluster

# SOMS cluster per sample -------------------------------------------------
ggplot(cluster, aes(UMAP_X_rPCA, UMAP_Y_rPCA, color=as.factor(FlowSOM_metacluster)))+
  geom_point(show.legend=T)+theme(legend.title = element_text(size=0))+facet_wrap(~sample)

# Pheatmap ----------------------------------------------------------------

exp <- do.aggregate(data, grep("aligned", colnames(data), value=T), by = "FlowSOM_metacluster")
make.pheatmap(exp, "FlowSOM_metacluster",  grep("aligned", colnames(data), value=T), path="output/features");dev.off()

# Proportions by Cluster --------------------------------------------------

data %>% group_by(sample) %>%
  mutate(prop=1/length(FlowSOM_metacluster)) %>%
  ungroup() %>%
  group_by(FlowSOM_metacluster,sample) %>%
  summarise(totprop=sum(prop)) %>%
  ggplot(aes(x=factor(FlowSOM_metacluster),fill=factor(sample),y=totprop)) +
  geom_bar(position='fill', stat='identity') + theme_classic()+RotatedAxis()+
  labs(x="", y="")+theme(legend.title = element_text(size=0))

# Proportions by Sample --------------------------------------------------

data %>% group_by(FlowSOM_metacluster) %>%
  mutate(prop=1/length(sample)) %>%
  ungroup() %>%
  group_by(sample,FlowSOM_metacluster) %>%
  summarise(totprop=sum(prop)) %>%
  ggplot(aes(x=factor(sample),fill=as.factor(FlowSOM_metacluster),y=totprop)) +
  geom_bar(position='fill', stat='identity') + theme_classic()+RotatedAxis()+
  labs(x="", y="")+theme(legend.title = element_text(size=0))


# FeaturePlots ------------------------------------------------------------

for(i in 1:length(unique(grep("aligned", colnames(cluster), value=T)))) {
  make.colour.plot(cluster, "UMAP_X_rPCA", "UMAP_Y_rPCA", unique(grep("aligned", colnames(cluster), value=T))[i], path="output/features", blank.axis = T)
}