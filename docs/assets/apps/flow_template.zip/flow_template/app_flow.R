
wd <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(wd)

if(!file.exists("flow")){dir.create("flow")}
if(!file.exists("meta")){dir.create("meta")}
if(!file.exists("output")){dir.create("output"); dir.create("output/rds"); dir.create("output/features")}

library(Spectre)
library(Seurat)
library(ggplot2)
library(shiny)
library(DT)
library(data.table)

#data setup

source("https://raw.githubusercontent.com/CVR-MucosalImmunology/Rshiny/refs/heads/main/flow_setup.R");shinyApp(ui,server);rm(ui,server)

# integration

source("https://raw.githubusercontent.com/CVR-MucosalImmunology/Rshiny/refs/heads/main/flow_integration.R");shinyApp(ui,server);rm(ui,server)
